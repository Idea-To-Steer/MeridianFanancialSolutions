<?php /* Template Name: About us */ ?>

<?php 

	get_header(); 

?>


<!-- About-banner Start -->
<div class="about-banner">
	<div class="banner-desc">
		<div class="container">
			<div class="text-block">
				<h2>About Us</h2>
			</div>
			<div class="breadcrumb">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">About</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>

<!-- Our-story Start -->
<div class="our-story">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="box">
					<div class="img-panel">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/story-img.jpg" alt="" />
					</div>
					<div class="icon">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/story-icon.png" alt="" />
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="text-panel">
					<h3>We Are Industry Experts Committed To Your Growth</h3>
					<p>Our company name Meridian conjures images of early voyagers setting off into the unknown, guided by the prime meridian.  It speaks  to our internal moral compass providing a sense of direction for our business based on a desire to do good, and build mutually beneficial relationships.</p>
					<p>Meridian’s founding in 2006 brought together a powerful product leadership team credited with:</p>
					<div class="box">
	<h4>Big Four</h4>
	<h5>experience dating back to the late 1980s.</h5>
</div>
<div class="box">
	<h4>Expert witness</h4>
	<h5>status in the tax courts in cost segregation</h5>
</div>
<div class="box">
	<h4>Leadership or</h4>
	<h5>supporting roles in several landmark court cases</h5>
</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="img-panel">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/story-2.jpg" alt="" />
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="text-panel">
					<h3>We’re committed to a standard set of values, strong customer relationships, and meaningful collaboration.</h3>
					<p>We’re committed to a standard set of values, strong customer relationships, and meaningful collaboration.</p>
					<p>Every tax services firm will tell you they provide quality product, timely reporting, and great communication.  At Meridian, those are just the basic elements of good business. Our focus from the day our firm launched has been on building relationships.  Client service is the motivation behind all our actions to provide nothing less than exceptional value for our clients.</p>
				</div>
<!-- 				<ul>
					<li>Big Four experience dating back to the late 1980s </li>
					<li>Expert witness status in the tax courts in cost segregation</li>
					<li>Leadership or supporting roles in several landmark court cases</li>
				</ul> -->
			</div>
		</div>
	</div>
</div>

<!-- Still-service Start -->
<div class="still-service">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="img-panel">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/metting.jpg" alt="" />
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="text-panel">
					<h2>After 15 years, we are still serving our first client.  </h2>
					<p>It started with a single service - cost segregation. Over the years we found more great partners who share the same philosophy. By focusing exclusively on value-added tax services that complement your traditional accounting team, we expanded our offerings. We now bring together over 300 years of combined experience in real estate, construction, sustainability, engineering, and tax law.  Founded on the principle that it is best to do one thing really, well, all our experts are singularly focused. With offices across the U.S., our team of tax specialists are considered the best in their respective industries.</p>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- How-we-block Start -->
<div class="how-we-block">
	<div class="container">
		<div class="title">
			<h2>How we add value</h2>
			<p>The best kind of service makes you smarter and ultimately puts you in control by providing access to the resources you need –  delivering real value, resulting in significant, substantiated quantitative and qualitative return on investment.</p>
		</div>
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="rt-side">
					<div class="img-panel">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/how-we-img.jpg" alt="" />
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-12">
				<div class="box">
					<div class="img-panel">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/img-1.png" alt="" />
					</div>
					<div class="text-panel">
						<h3>In The Short Term</h3>
						<p>We enable clients to maximize tax deductions and credits to increase cash flow to expand the business, reduce debt, pay off capital expenditures, and increase earnings. </p>
					</div>
				</div>
				<div class="box">
					<div class="img-panel">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/img-2.png" alt="" />
					</div>
					<div class="text-panel">
						<h3>In The Short Term</h3>
						<p>We enable clients to maximize tax deductions and credits to increase cash flow to expand the business, reduce debt, pay off capital expenditures, and increase earnings. </p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Advantage-block Start -->
<div class="advantage-block">
	<div class="container">
		<div class="text-block">
			<h2>Experience the Meridian Advantage.</h2>
			<p>Proper tax planning creates future opportunity. Reduce the tax impact of your investments today and retain more of your gains and create greater tax efficiencies in future years.</p>
			<p>Proper tax planning creates future opportunity. Reduce the tax impact of your investments today, retain more of your gains and create greater tax efficiencies in future years. Work with us and experience the Meridian advantage.</p>
		</div>
	</div>
</div>

<!-- Based-block Start -->
<div class="based-block">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 col-md-5 col-sm-12">
				<div class="img-panel">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/partnership-2.jpg" alt="" />
				</div>
			</div>
			<div class="col-lg-7 col-md-7 col-sm-12">
				<div class="text-panel">
					<h2>Our service is based on a win-win partnership with you.</h2>
					<p>Fees are incurred only when savings are identified.</p>
					<ul>
						<li>We can scale our solutions to provide flexible support based on your needs</li>
						<li>We’re capable of sticking to a budget for each deal – no surprises
							<ul>
								<li>Flat fee - based on the time to complete the project. Works best when project scope is clear.</li>
								<li>Fee range - clarifies minimum and maximum fee. Ideal when the project scale is flexible based on our findings.</li>
								<li>Success based </li>
							</ul>
						</li>
						<li>We provide a flat, all-inclusive fee based on either time to conduct the project, or a percentage of benefits</li>
					</ul>
					<p>Every client and situation is unique. </p>
					<p>We don’t always have an immediate solution, and sometimes the best course of action is to do nothing.  You can count on us to make long-term recommendations appropriate for you –even if it means we lose the business.</p>
				</div>
			</div>
		</div>
	</div>
</div>



<?php get_footer(); ?>