<!-- Footer Start -->
<div class="footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-12">
				<div class="box">
					<div class="logo-block">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/f-logo.png" alt="">
					</div>
					<p>Offices In: 27 N Wacker Drive, Suite 427, Chicago, IL 60606</p>
<!-- 					<div class="social-block">
						<ul>
							<li><a href="#"><i class="fab fa-facebook"></i></a></li>
							<li><a href="#"><i class="fab fa-instagram"></i></a></li>
							<li><a href="#"><i class="fab fa-twitter"></i></a></li>
						</ul>
					</div> -->
				</div>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-12">
				<div class="box">
					<ul>
						<li><a href="#">Home</a></li>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Service</a></li>
						<li><a href="#">Contact Us</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-md-2 col-sm-12">
				<div class="touch">
					<h3>Get in touch</h3>
					<ul>
						<li><a href="tel:4805550103">(480) 555-0103</a></li>
<!-- 						<li><a href="mailto:debra.holt@example.com">debra.holt@example.com</a></li> -->
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-md-4 col-sm-12 loca_wr">
				<div class="location">
					<p>Atlanta, Chicago, Houston, Jupiter, New York, And Tampa</p>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Copy-right Start -->
<div class="copy-right">
	<div class="container">
		<p>Copyright 2019-2021, Meridian Fimamcial solutions, LLC. all Rights reserved.</p>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>