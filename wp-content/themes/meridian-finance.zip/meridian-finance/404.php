<?php get_header(); ?>
<h2><?php _e('Error') ?> 404 - <?php _e('Not Found') ?></h2>
<?php get_footer(); ?>