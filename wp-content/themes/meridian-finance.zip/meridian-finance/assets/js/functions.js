jQuery(document).ready(function(){

jQuery('.banner-slider').slick({
  autoplay:true,
  autoplaySpeed: 9000,
  infinite: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  dots:true,
  arrows:false,
});

jQuery('.slider').slick({
  infinite: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  dots:false,
  arrows:true,
  autoplay:true,
});
	
jQuery(document).on("scroll", function(){
	if
  (jQuery(document).scrollTop() > 20){
	  jQuery(".navbar-default").addClass("navbar-shrink");
	}
	else
	{
		jQuery(".navbar-default").removeClass("navbar-shrink");
	}
});

jQuery(function () {
	jQuery(".content").css("display", "none");
	jQuery(".js-accordion-title").addClass("open");
	jQuery(".js-accordion-title").click(function () {
		jQuery(".open").not(this).removeClass("open").next().slideUp(300);
		jQuery(this).toggleClass("open").next().slideToggle(300);
	});
});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

});